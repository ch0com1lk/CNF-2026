# Forward-Backward asymmetry en $e^+e^-\to\mu^+\mu^-$: simulación Monte Carlo

Estudio fenomenológico de la **Forward-Backward asymmetry** ($A_{FB}$) mediante técnicas de simulación numérica. La asimetría surge de la interferencia entre el intercambio de un fotón virtual y del bosón $Z$. La distribución angular de los muones se genera con el método de **aceptación-rechazo** en Python (solo `numpy` y `matplotlib`), con el propagador de Breit-Wigner incluido.

## Plan de trabajo y dónde se cubre

| # | Punto del plan | Dónde |
|---|---|---|
| 1 | Análisis fenomenológico de $e^+e^-\to\mu^+\mu^-$ | `notebooks/01`, `docs/teoria.md` |
| 2 | Sección eficaz diferencial a partir de la amplitud | `notebooks/01`, `src/fbasym/physics.py` |
| 3 | Términos de interferencia $\gamma$–$Z$ | `notebooks/01`, `src/fbasym/physics.py` |
| 4 | Monte Carlo (aceptación-rechazo), varias energías $\sqrt{s}$, $\sqrt{s}=m_Z=91.1876$ GeV, Breit-Wigner | `notebooks/02`, `notebooks/03`, `src/fbasym/sampling.py` |
| 5 | Distribución simétrica (solo fotón) | `notebooks/02` |
| 6 | Transición de la distribución simétrica a la asimétrica | `notebooks/03` |
| 7 | Sensibilidad del método para extraer parámetros físicos | `notebooks/04` |
| 8 | Para cada ángulo de 0° a 180°: partículas por grado | `notebooks/05`, `data/conteo_angular.csv` |

## Estructura del repositorio

```
fb-asymmetry-montecarlo/
├── README.md
├── requirements.txt
├── .gitignore
├── docs/
│   └── teoria.md                     # derivación completa
├── src/fbasym/
│   ├── __init__.py
│   ├── physics.py                    # A(s), B(s), propagador, A_FB, derivadas
│   ├── sampling.py                   # aceptación-rechazo, A_FB medida y su error
│   ├── analysis.py                   # chi2, conteo por grado, extracción de sin^2(theta_W)
│   └── plots.py                      # todas las figuras
├── notebooks/
│   ├── 01_fenomenologia_y_coeficientes.ipynb
│   ├── 02_simulacion_tres_casos.ipynb
│   ├── 03_transicion_con_la_energia.ipynb
│   ├── 04_sensibilidad_sin2thetaW.ipynb
│   └── 05_conteo_por_grado.ipynb
├── tests/
│   └── test_fbasym.py
├── data/
│   └── conteo_angular.csv            # 180 filas: partículas por grado
└── figures/                          # PNG generados por los notebooks
```

## Instalación y uso

```bash
git clone <url-del-repositorio>
cd fb-asymmetry-montecarlo
python -m venv .venv
source .venv/bin/activate            # en Windows: .venv\Scripts\activate
pip install -r requirements.txt

jupyter notebook notebooks/          # ejecutar los notebooks en orden 01 -> 05
pytest                               # pruebas
```

Los notebooks importan el paquete con `sys.path.append("../src")`, de modo que no hace falta instalarlo. Deben ejecutarse desde la carpeta `notebooks/`, porque guardan figuras en `../figures` y datos en `../data`. Las semillas están fijadas (`np.random.seed`), por lo que los resultados son reproducibles.

## Resultados principales

- **Polo de la $Z$** ($\sqrt{s}=m_Z$): $A_{NC}=167.93$, $B_{NC}=7.42$ y $A_{FB}=+0.0166$. En el polo la interferencia se anula y la asimetría remanente proviene del término $ZZ$.
- **Transición:** la $A_{FB}$ es negativa debajo de la resonancia, cruza casi por cero en el polo y llega a $\approx0.7$ a 105 GeV.
- **Sensibilidad:** el error de $A_{FB}$ decrece como $1/\sqrt{N}$. Con $N=10^5$ eventos se recupera $\sin^2\theta_W=0.2313\pm0.0020$ (valor verdadero 0.23126). La sensibilidad es máxima cerca del polo.
- **Conteo por grado:** las 10 000 partículas se reparten en 180 intervalos de $1^\circ$ y siguen la predicción teórica. A $\sqrt{s}=80$ GeV, 8639 partículas salen hacia atrás y 1361 hacia adelante; a 105 GeV la proporción se invierte (8511 hacia adelante).

![Coeficientes vs energía](figures/01_coeficientes_vs_energia.png)

![Conteo por grado](figures/05_conteo_por_grado_casos.png)

## Limitaciones

Cálculo a nivel árbol, sin correcciones radiativas, sin radiación de estado inicial, sin efectos del detector, y solo con la forma angular (no la sección eficaz absoluta).

## Autoría

M. Salinas Ibáñez, V. López Agustín, H. Novales Sánchez.
Proyecto presentado en el CNF 2026, área Partículas y Campos.

## Licencia

Pendiente de definir antes de publicar (por ejemplo MIT para el código).
