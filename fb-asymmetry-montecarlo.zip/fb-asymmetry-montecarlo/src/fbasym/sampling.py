"""Generación de eventos por el método de aceptación-rechazo."""
import numpy as np
from .physics import f


def rejection_sampling(A, B, n_events, x_min=-1.0, x_max=1.0, lote=20000):
    """Genera n_events valores de x = cos(theta) con distribución f(x) = A(1+x^2) + Bx.

    Pasos: (1) proponer x uniforme, (2) proponer y uniforme en [0, f_max],
    (3) aceptar si y <= f(x). Devuelve (eventos, eficiencia en %).
    """
    x_test = np.linspace(x_min, x_max, 1000)
    if np.min(f(x_test, A, B)) < 0:
        raise ValueError("f(x) es negativa: con esos A y B no es una probabilidad")
    f_max = np.max(f(x_test, A, B)) * 1.05          # techo del rectángulo

    aceptados = np.array([])
    intentos = 0
    while len(aceptados) < n_events:
        x_prop = np.random.uniform(x_min, x_max, lote)
        y_prop = np.random.uniform(0, f_max, lote)
        aceptados = np.concatenate([aceptados, x_prop[y_prop <= f(x_prop, A, B)]])
        intentos += lote

    return aceptados[:n_events], n_events / intentos * 100


def asimetria_fb(x):
    """A_FB medida: (N_forward - N_backward) / N_total."""
    return (np.sum(x > 0) - np.sum(x < 0)) / len(x)


def error_afb(afb, n):
    """Error estadístico de A_FB."""
    return np.sqrt((1 - afb**2) / n)
