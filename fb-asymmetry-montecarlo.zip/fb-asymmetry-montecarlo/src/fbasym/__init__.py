"""fbasym: simulación Monte Carlo de la Forward-Backward asymmetry en e+e- -> mu+mu-."""
from .physics import (M_Z, GAMMA_Z, S2W, propagador, coeficientes, terminos_A,
                      f, afb_teorica, derivada_afb, primitiva)
from .sampling import rejection_sampling, asimetria_fb, error_afb
from .analysis import (chi2_y_pulls, particulas_por_grado, esperado_por_grado,
                       construir_inversor_s2w)
