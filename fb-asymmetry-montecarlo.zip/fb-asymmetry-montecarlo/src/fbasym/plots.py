"""Funciones de graficación (todas devuelven la figura de matplotlib)."""
import numpy as np
import matplotlib.pyplot as plt
from .physics import (M_Z, f, primitiva, coeficientes, terminos_A, afb_teorica)
from .sampling import error_afb
from .analysis import chi2_y_pulls, esperado_por_grado


def _estilo(ax, xlabel, ylabel, titulo):
    ax.set_xlabel(xlabel, fontsize=13)
    ax.set_ylabel(ylabel, fontsize=13)
    ax.set_title(titulo, fontsize=13)
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3, linestyle='--')


def _linea_mz(ax):
    ax.axvline(M_Z, color='red', linestyle=':', linewidth=1.5, label=f'$m_Z = {M_Z}$ GeV')


def histograma_eventos(ax, eventos, A, B, etiqueta_teoria, titulo, bins=100):
    """Histograma dorado de eventos + curva teórica roja (densidad normalizada)."""
    ax.hist(eventos, bins=bins, density=True, alpha=0.7, color='goldenrod',
            edgecolor='black', linewidth=0.5, label='eventos simulados (mc)')
    x = np.linspace(-1, 1, 1000)
    norma = primitiva(1, A, B) - primitiva(-1, A, B)
    ax.plot(x, f(x, A, B) / norma, 'r-', linewidth=2.5, label=etiqueta_teoria)
    _estilo(ax, r'$x = \cos(\theta)$', 'densidad de probabilidad', titulo)


def figura_caso(eventos, A, B, etiqueta_teoria, titulo):
    """Histograma vs teoría (izquierda) y residuos normalizados (derecha)."""
    chi2, ndof, centros, pulls = chi2_y_pulls(eventos, A, B)
    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5))
    histograma_eventos(axes[0], eventos, A, B, etiqueta_teoria, titulo)
    ax = axes[1]
    ax.plot(centros, pulls, 'b-o', linewidth=2, markersize=4, label='residuos normalizados')
    ax.axhline(0, color='red', linestyle=':', linewidth=1.5, label='ajuste perfecto')
    ax.axhline(2, color='green', linestyle='--', linewidth=1.5, label=r'$\pm 2\sigma$')
    ax.axhline(-2, color='green', linestyle='--', linewidth=1.5)
    ax.set_ylim(-4, 4)
    _estilo(ax, r'$x = \cos(\theta)$', r'$(O_i - E_i)/\sqrt{E_i}$',
            rf'Residuos: $\chi^2/ndof = {chi2/ndof:.2f}$')
    fig.tight_layout()
    return fig


def figura_coeficientes(energias):
    """A_NC y |B_NC|, Forward-Backward asymmetry y peso relativo de cada término de A_NC."""
    A = np.array([coeficientes(E)[0] for E in energias])
    B = np.array([coeficientes(E)[1] for E in energias])
    T = np.array([terminos_A(E) for E in energias])
    fig, axes = plt.subplots(1, 3, figsize=(18, 5.5))

    ax = axes[0]
    ax.plot(energias, A, 'b-', linewidth=2, label=r'$A_{NC}(\sqrt{s})$')
    ax.plot(energias, np.abs(B), 'g--', linewidth=2, label=r'$|B_{NC}(\sqrt{s})|$')
    _linea_mz(ax)
    ax.set_yscale('log')
    _estilo(ax, r'$\sqrt{s}$ [GeV]', 'Coeficiente (Escala log)',
            'Coeficientes $A_{NC}$ y $|B_{NC}|$ vs Energía')

    ax = axes[1]
    ax.plot(energias, 3 * B / (8 * A), 'b-', linewidth=2, label=r'$A_{FB}(\sqrt{s})$ teórica')
    ax.axhline(0, color='black', linewidth=0.8)
    _linea_mz(ax)
    _estilo(ax, r'$\sqrt{s}$ [GeV]', r'$A_{FB} = \frac{3}{8}\,B_{NC}/A_{NC}$',
            'Forward-Backward asymmetry vs Energía')

    ax = axes[2]
    frac = T / A[:, None]
    colores = ['steelblue', 'darkorange', 'seagreen']
    nombres = [r'$\gamma\gamma$', r'interferencia $\gamma Z$', r'$ZZ$']
    for j in range(3):
        ax.fill_between(energias, frac[:, j], 0, color=colores[j], alpha=0.25)
        ax.plot(energias, frac[:, j], color=colores[j], linewidth=2.5, label=nombres[j])
    ax.axhline(0, color='black', linewidth=0.8)
    ax.axvline(M_Z, color='dimgray', linestyle='--', linewidth=1.2)
    ax.text(M_Z + 1.5, 0.55, r'$m_Z$', color='dimgray', fontsize=12)
    ax.set_xlim(50, 140)
    _estilo(ax, r'$\sqrt{s}$ [GeV]', r'Fracción de $A_{NC}$',
            'Peso relativo de cada contribución a $A_{NC}$')
    ax.legend(fontsize=11, loc='center left')
    fig.tight_layout()
    return fig


def figura_histogramas_energia(lista_eventos):
    """Cuadrícula 2x3 de histogramas; lista_eventos = [(E, eventos), ...]."""
    fig, ejes = plt.subplots(2, 3, figsize=(16, 9))
    for ax, (E, ev) in zip(ejes.flatten(), lista_eventos):
        A, B = coeficientes(E)
        afb = (np.sum(ev > 0) - np.sum(ev < 0)) / len(ev)
        histograma_eventos(ax, ev, A, B, 'teoría',
                           rf'$\sqrt{{s}}={E}$ GeV   $A_{{FB}}$={afb:+.3f}', bins=50)
        ax.set_ylim(0, 1.25)
    fig.tight_layout()
    return fig


def figura_transicion(energias_curvas, energias_fino, energias_scan, afb_mc, err_mc, n_events):
    """Forma de f(x) a varias energías y barrido de A_FB (teoría vs simulación)."""
    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5))
    ax = axes[0]
    x = np.linspace(-1, 1, 500)
    for est, E in zip(['b-', 'g--', 'k-', 'r:', 'm-.'], energias_curvas):
        A, B = coeficientes(E)
        norma = primitiva(1, A, B) - primitiva(-1, A, B)
        ax.plot(x, f(x, A, B) / norma, est, linewidth=2, label=rf'$\sqrt{{s}}={E:g}$ GeV')
    _estilo(ax, r'$x = \cos(\theta)$', 'densidad de probabilidad', 'Forma de $f(x)$ a distintas energías')

    ax = axes[1]
    ax.plot(energias_fino, [afb_teorica(E) for E in energias_fino], 'b-', linewidth=2, label='teoría')
    ax.errorbar(energias_scan, afb_mc, yerr=err_mc, fmt='o', color='green', ecolor='green',
                capsize=3, markersize=5, label=f'simulación ({n_events} eventos)')
    ax.axhline(0, color='black', linewidth=0.8)
    _linea_mz(ax)
    _estilo(ax, r'$\sqrt{s}$ [GeV]', r'$A_{FB}$', 'Forward-Backward asymmetry: teoría vs simulación')
    fig.tight_layout()
    return fig


def figura_error_vs_N(tamanos, dispersion, medidas_afb):
    """Dispersión de A_FB contra N y distribución de las medidas."""
    N_fino = np.logspace(np.log10(min(tamanos)), np.log10(max(tamanos)), 50)
    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5))
    ax = axes[0]
    ax.plot(N_fino, 1 / np.sqrt(N_fino), 'b-', linewidth=2, label=r'teoría: $1/\sqrt{N}$')
    ax.plot(tamanos, dispersion, 'go', markersize=9, label='simulación')
    ax.set_xscale('log'); ax.set_yscale('log')
    _estilo(ax, 'N (eventos por experimento)', r'desviación de $A_{FB}$',
            r'Error estadístico de $A_{FB}$ en $\sqrt{s}=m_Z$')

    ax = axes[1]
    for N, col in zip(tamanos, ['b', 'g', 'r']):
        ax.hist(medidas_afb[N], bins=20, alpha=0.5, color=col, edgecolor='black',
                linewidth=0.4, label=f'N = {N}')
    ax.axvline(afb_teorica(M_Z), color='black', linestyle=':', linewidth=1.5,
               label=rf'$A_{{FB}}$ teórica = {afb_teorica(M_Z):.4f}')
    _estilo(ax, r'$A_{FB}$ medida', 'número de experimentos', 'Las medidas se concentran al aumentar N')
    fig.tight_layout()
    return fig


def figura_sensibilidad_energia(E, derivada, sigma_s2w):
    """Sensibilidad de A_FB a sin^2(theta_W) y error esperado, por energía."""
    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5))
    ax = axes[0]
    ax.plot(E, np.abs(derivada), 'b-', linewidth=2, label=r'$|\partial A_{FB}/\partial \sin^2\theta_W|$')
    _linea_mz(ax)
    ax.set_yscale('log')
    _estilo(ax, r'$\sqrt{s}$ [GeV]', 'Sensibilidad (Escala log)',
            r'Dependencia de $A_{FB}$ respecto a $\sin^2\theta_W$')

    ax = axes[1]
    ax.plot(E, sigma_s2w, 'g--', linewidth=2, label=r'$\sigma_{\sin^2\theta_W}$ con $N=10^5$')
    _linea_mz(ax)
    ax.set_yscale('log')
    ax.set_ylim(5e-4, 1e-1)
    _estilo(ax, r'$\sqrt{s}$ [GeV]', r'error esperado en $\sin^2\theta_W$ (Escala log)',
            'Energía óptima de medición')
    fig.tight_layout()
    return fig


def figura_extraccion(tamanos, resultados, sigma_sim, N_fino, sigma_teo, s2w_verdadero):
    """Histogramas de sin^2(theta_W) extraído y precisión contra N."""
    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5))
    ax = axes[0]
    for N, col in zip(tamanos, ['b', 'g', 'r']):
        ax.hist(resultados[N], bins=20, alpha=0.5, color=col, edgecolor='black',
                linewidth=0.4, label=f'N = {N}')
    ax.axvline(s2w_verdadero, color='black', linestyle=':', linewidth=1.8,
               label=rf'valor verdadero ${s2w_verdadero}$')
    _estilo(ax, r'$\sin^2\theta_W$ extraído', 'número de experimentos',
            r'Recuperación de $\sin^2\theta_W$ con Monte Carlo')

    ax = axes[1]
    ax.plot(N_fino, sigma_teo, 'b-', linewidth=2,
            label=r'predicción: $\sigma_{A_{FB}}/|\partial A_{FB}/\partial\sin^2\theta_W|$')
    ax.plot(tamanos, sigma_sim, 'go', markersize=9, label='simulación')
    ax.set_xscale('log'); ax.set_yscale('log')
    _estilo(ax, 'N (eventos por experimento)', r'incertidumbre en $\sin^2\theta_W$',
            'Precisión del método vs número de eventos')
    fig.tight_layout()
    return fig


def figura_conteo_casos(casos, columnas):
    """Barras de partículas por grado con la curva teórica; casos = [(nombre, A, B, n)]."""
    grados = np.arange(180) + 0.5
    fig, axes = plt.subplots(1, 3, figsize=(18, 5.5))
    for ax, (nombre, A, B, n), cuentas in zip(axes, casos, columnas):
        ax.bar(grados, cuentas, width=1.0, alpha=0.7, color='goldenrod',
               edgecolor='black', linewidth=0.3, label='eventos simulados (mc)')
        ax.plot(grados, esperado_por_grado(A, B, n), 'r-', linewidth=2.5, label='teoría')
        ax.set_xlim(0, 180)
        ax.set_xticks(range(0, 181, 30))
        _estilo(ax, r'$\theta$ [grados]', 'partículas por grado', nombre)
    fig.tight_layout()
    return fig


def figura_conteo_comparacion(series, titulo_izq='Comparación del conteo angular',
                              titulo_der='Conteo acumulado'):
    """Conteo por grado y fracción acumulada; series = [(etiqueta, estilo, cuentas)]."""
    grados = np.arange(180) + 0.5
    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5))
    for etiqueta, est, cuentas in series:
        axes[0].plot(grados, cuentas, est, linewidth=2, label=etiqueta)
        axes[1].plot(np.arange(1, 181), np.cumsum(cuentas) / cuentas.sum(), est,
                     linewidth=2, label=etiqueta)
    axes[1].axvline(90, color='black', linestyle=':', linewidth=1.5, label=r'$\theta=90^\circ$')
    for ax, tit, yl in zip(axes, [titulo_izq, titulo_der],
                           ['partículas por grado', r'fracción de partículas con ángulo $<\theta$']):
        ax.set_xlim(0, 180)
        ax.set_xticks(range(0, 181, 30))
        _estilo(ax, r'$\theta$ [grados]', yl, tit)
    fig.tight_layout()
    return fig
