"""Física del proceso e+e- -> mu+mu- (nivel árbol, fotón + Z, fermiones sin masa).

La distribución angular tiene la forma  f(x) = A (1 + x^2) + B x,  con x = cos(theta).
A y B se obtienen de las amplitudes de helicidad (helicity amplitudes):

    a_ij = Q_e Q_mu + g_i g_j chi(s),      i, j = L, R
    A = (|a_LL|^2 + |a_RR|^2 + |a_LR|^2 + |a_RL|^2) / 4
    B = (|a_LL|^2 + |a_RR|^2 - |a_LR|^2 - |a_RL|^2) / 2

Ver docs/teoria.md para la derivación completa.
"""
import numpy as np

# ---- parámetros (GeV) ----
M_Z = 91.1876        # masa del bosón Z
GAMMA_Z = 2.4952     # anchura de la resonancia
S2W = 0.23126        # sin^2(theta_W)

Q_LEPTON = -1.0      # carga del electrón y del muón
T3_LEPTON = -0.5     # isospín débil (componente izquierda)


def propagador(raiz_s, s2w=S2W):
    """chi(s): propagador de Breit-Wigner de la Z, normalizado respecto al del fotón."""
    s = raiz_s**2
    return s / (s - M_Z**2 + 1j * M_Z * GAMMA_Z) / (s2w * (1 - s2w))


def _acoplamientos(s2w):
    gL = T3_LEPTON - Q_LEPTON * s2w
    gR = -Q_LEPTON * s2w
    return gL, gR


def coeficientes(raiz_s, s2w=S2W):
    """Devuelve (A, B) de f(x) = A(1+x^2) + B x a la energía raiz_s (GeV)."""
    gL, gR = _acoplamientos(s2w)
    chi = propagador(raiz_s, s2w)

    def a(gi, gj):
        return Q_LEPTON * Q_LEPTON + gi * gj * chi

    S_igual = abs(a(gL, gL))**2 + abs(a(gR, gR))**2     # LL + RR
    S_dif = abs(a(gL, gR))**2 + abs(a(gR, gL))**2       # LR + RL
    return (S_igual + S_dif) / 4, (S_igual - S_dif) / 2


def terminos_A(raiz_s, s2w=S2W):
    """Descompone A en (gamma-gamma, interferencia gamma-Z, ZZ)."""
    gL, gR = _acoplamientos(s2w)
    chi = propagador(raiz_s, s2w)
    A_gg = Q_LEPTON**4
    A_int = Q_LEPTON**2 * chi.real * (gL + gR)**2 / 2
    A_zz = (gL**2 + gR**2)**2 * abs(chi)**2 / 4
    return A_gg, A_int, A_zz


def f(x, A, B):
    """Distribución angular (sin normalizar)."""
    return A * (1 + x**2) + B * x


def primitiva(x, A, B):
    """Integral indefinida de f(x); permite normalizar y calcular probabilidades exactas."""
    return A * (x + x**3 / 3) + B * x**2 / 2


def afb_teorica(raiz_s, s2w=S2W):
    """A_FB = (3/8) B/A."""
    A, B = coeficientes(raiz_s, s2w)
    return 3 * B / (8 * A)


def derivada_afb(raiz_s, s2w=S2W, h=1e-4):
    """dA_FB / d(sin^2 theta_W) por diferencia finita centrada."""
    return (afb_teorica(raiz_s, s2w + h) - afb_teorica(raiz_s, s2w - h)) / (2 * h)
