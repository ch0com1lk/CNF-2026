"""Herramientas de análisis: chi2, conteo por grado y extracción de sin^2(theta_W)."""
import numpy as np
from .physics import f, primitiva, afb_teorica, M_Z


def chi2_y_pulls(eventos, A, B, n_bins=30):
    """chi2, grados de libertad, centros de bin y residuos (O - E)/sqrt(E)."""
    obs, bordes = np.histogram(eventos, bins=n_bins, range=(-1, 1))
    centros = (bordes[:-1] + bordes[1:]) / 2
    esperado = len(eventos) * (primitiva(bordes[1:], A, B) - primitiva(bordes[:-1], A, B)) \
        / (primitiva(1, A, B) - primitiva(-1, A, B))
    pulls = (obs - esperado) / np.sqrt(esperado)
    return np.sum(pulls**2), n_bins - 1, centros, pulls


def particulas_por_grado(eventos):
    """Cuenta partículas en cada intervalo [k, k+1) grados, k = 0..179.

    El último intervalo incluye el extremo de 180 grados.
    Devuelve (cuentas, theta en grados).
    """
    theta = np.degrees(np.arccos(np.clip(eventos, -1, 1)))
    cuentas = np.zeros(180, dtype=int)
    for k in range(180):
        if k < 179:
            en_el_grado = (theta >= k) & (theta < k + 1)
        else:
            en_el_grado = (theta >= k) & (theta <= k + 1)
        cuentas[k] = np.sum(en_el_grado)
    return cuentas, theta


def esperado_por_grado(A, B, n):
    """Predicción teórica de partículas por grado: n * P(k < theta < k+1)."""
    xb = np.cos(np.radians(np.arange(0, 181)))
    return n * (primitiva(xb[:-1], A, B) - primitiva(xb[1:], A, B)) \
        / (primitiva(1, A, B) - primitiva(-1, A, B))


def construir_inversor_s2w(raiz_s=M_Z, s2w_min=0.20, s2w_max=0.245, n=200):
    """Devuelve una función A_FB medida -> sin^2(theta_W), por interpolación.

    Se usa un intervalo donde A_FB(sin^2 theta_W) es monótona (decreciente en el polo).
    """
    rejilla = np.linspace(s2w_min, s2w_max, n)
    afb = np.array([afb_teorica(raiz_s, v) for v in rejilla])

    def extraer(afb_medida):
        return np.interp(afb_medida, afb[::-1], rejilla[::-1])
    return extraer
