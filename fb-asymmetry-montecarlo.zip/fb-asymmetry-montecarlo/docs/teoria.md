# Teoría

Derivación de la distribución angular de $e^+e^-\to\mu^+\mu^-$ con fotón y bosón $Z$, a nivel árbol y con fermiones sin masa.

## 1. Fenomenología del proceso

El $e^+e^-$ se aniquila en un bosón virtual ($\gamma$ o $Z$) que se convierte en un par $\mu^+\mu^-$. Se define $x=\cos\theta$, con $\theta$ el ángulo entre el $\mu^-$ saliente y el haz de $e^-$.

- $x\to1$ ($\theta\to0$): *forward*
- $x\to-1$ ($\theta\to\pi$): *backward*

## 2. Sección eficaz a partir de la amplitud

Para un electrón de quiralidad $i$ y un muón de quiralidad $j$ ($i,j=L,R$):

$$\mathcal{M}_{ij}\propto\frac{e^2}{s}\left[Q_eQ_\mu+g_i^e g_j^\mu\,\chi(s)\right]\times(\text{helicity spinors})$$

$$\chi(s)=\frac{1}{\sin^2\theta_W\cos^2\theta_W}\,\frac{s}{s-m_Z^2+i\,m_Z\Gamma_Z}\qquad\text{(propagador de Breit-Wigner)}$$

$$g_L=T_3-Q\sin^2\theta_W,\qquad g_R=-Q\sin^2\theta_W\qquad(Q=-1,\ T_3=-\tfrac12)$$

El factor de los *helicity spinors*, al cuadrado, vale $(1+x)^2$ para $i=j$ ($LL$, $RR$) y $(1-x)^2$ para $i\ne j$ ($LR$, $RL$). Sumando sobre helicidades:

$$\frac{d\sigma}{dx}=\frac{\pi\alpha^2}{8s}\left[S_{=}(1+x)^2+S_{\neq}(1-x)^2\right]$$

con $S_{=}=|a_{LL}|^2+|a_{RR}|^2$, $S_{\neq}=|a_{LR}|^2+|a_{RL}|^2$ y $a_{ij}=Q_eQ_\mu+g_ig_j\chi(s)$. Como $(1\pm x)^2=1+x^2\pm2x$:

$$\frac{d\sigma}{dx}=\frac{\pi\alpha^2}{2s}\left[A(1+x^2)+Bx\right],\qquad A=\frac{S_{=}+S_{\neq}}{4},\quad B=\frac{S_{=}-S_{\neq}}{2}$$

Con solo el fotón, $\chi=0$, de modo que $A=1$ y $B=0$ (distribución simétrica $1+x^2$).

## 3. Términos de interferencia $\gamma$–$Z$

$$|a_{ij}|^2=\underbrace{Q_e^2Q_\mu^2}_{\gamma\gamma}+\underbrace{2Q_eQ_\mu g_ig_j\,\mathrm{Re}\,\chi}_{\text{interferencia}}+\underbrace{(g_ig_j)^2|\chi|^2}_{ZZ}$$

La interferencia es proporcional a $\mathrm{Re}\,\chi$: cambia de signo al cruzar $m_Z$ y se anula en el polo.

## 4. Forward-Backward asymmetry

$$A_{FB}=\frac{N_F-N_B}{N_F+N_B}=\frac{\int_0^1f\,dx-\int_{-1}^0f\,dx}{\int_{-1}^1f\,dx}=\frac{3}{8}\frac{B}{A}$$

## 5. Cambio de variable a ángulo

Como $dx=\sin\theta\,d\theta$, $\dfrac{dN}{d\theta}=\dfrac{dN}{dx}\sin\theta$. Por eso el conteo por grado no tiene la misma forma que el histograma en $x$.

## 6. Sensibilidad a $\sin^2\theta_W$

$$\sigma_{\sin^2\theta_W}\approx\frac{\sigma_{A_{FB}}}{\left|\partial A_{FB}/\partial\sin^2\theta_W\right|},\qquad \sigma_{A_{FB}}=\sqrt{\frac{1-A_{FB}^2}{N}}$$
